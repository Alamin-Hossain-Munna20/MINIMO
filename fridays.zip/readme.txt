TrueTypeFont: Fridays (2.0 updated 03/08/2015)
Dennis Ludlow 2000 all rights reserved
Sharkshock Productions
dennis@sharkshock.net


Many moons ago the inspiration for this font hit me while i was feasting on a glorious rack of ribs. It's undergone a few changes since 2000 (other than the name) but all positive. Fridays now
features a full character set with basic punctuation, improved drawing, and kerning added. Lowercase letters are the same as uppercase. The underscore will get you a festive little stripe. Press
its a few times for large one. 


For commercial use please contact me at dennis@sharkshock.net to discuss an end user license. I also design custom fonts for businesses, logos, and many other things. If you'd like to leave me a
donation you can use the same address via paypal. Your generosity will be most appreciated!


visit www.sharkshock.net for more and take a bite out of BORING design!

